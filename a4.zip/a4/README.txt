Lorraine Bichara
lb34995
CS 377 P

Cache-optimized MMM

To compile the code, unzip the file.
Inside that directory execute the command: make 
This will create an executable called "executable" linking to the required libraries and using the options.
To execute, run the following command: ./executable matrixSize
Be sure to include desired matrixSize as a command line argument.
When the program is executed, a menu will show, allowing the user to select the desired MMM method to perform.